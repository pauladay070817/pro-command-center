PRO COMMAND CENTER — CLOUD VERSION

1. Create a Supabase project.
2. In Supabase SQL Editor, run supabase_setup.sql.
3. In Supabase Storage, create a PRIVATE bucket named walk-photos.
4. Open the app, go to Cloud Setup, enter your Supabase Project URL and PUBLISHABLE key. Never use a secret/service-role key in the browser.
5. Create/sign in to your app account.
6. If you entered data before cloud setup, tap Sync Local Data once.
7. Future entries and walk photos save to the cloud.

The app still keeps a small local cache for offline-friendly display, but Supabase is the source of truth after sign-in.
