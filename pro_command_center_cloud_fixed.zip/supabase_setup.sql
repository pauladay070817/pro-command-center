-- Pro Business Command Center cloud setup for Supabase
-- Run this entire script in Supabase SQL Editor.
-- Then create a Storage bucket named: walk-photos

create table if not exists public.numbers (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  date date not null, store numeric default 0, store_plan numeric default 0, pro numeric default 0, pro_plan numeric default 0, credit numeric default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.specialists (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, sales numeric default 0, goal numeric default 0, credit numeric default 0, credit_goal numeric default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.departments (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, sales numeric default 0, plan numeric default 0, comp numeric default 0, pro numeric default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  name text not null, sales numeric default 0, plan numeric default 0, comp numeric default 0, pro numeric default 0,
  created_at timestamptz not null default now()
);
create table if not exists public.action_plans (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  focus text, problem text, action text, owner text, goal text, due date, status text default 'Open',
  created_at timestamptz not null default now()
);
create table if not exists public.daily_walks (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  date date not null, dep text, assoc text, obs text, action text, photo_path text,
  created_at timestamptz not null default now()
);

-- RLS + grants

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['numbers','specialists','departments','products','action_plans','daily_walks'] LOOP
    EXECUTE format('alter table public.%I enable row level security', t);
    EXECUTE format('revoke all on table public.%I from anon', t);
    EXECUTE format('grant select, insert, update, delete on table public.%I to authenticated', t);
  END LOOP;
END $$;

-- Policies: each signed-in user can only access their own rows.
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['numbers','specialists','departments','products','action_plans','daily_walks'] LOOP
    EXECUTE format('drop policy if exists "user_select_%s" on public.%I', t, t);
    EXECUTE format('drop policy if exists "user_insert_%s" on public.%I', t, t);
    EXECUTE format('drop policy if exists "user_update_%s" on public.%I', t, t);
    EXECUTE format('drop policy if exists "user_delete_%s" on public.%I', t, t);
    EXECUTE format('create policy "user_select_%s" on public.%I for select to authenticated using ((select auth.uid()) = user_id)', t, t);
    EXECUTE format('create policy "user_insert_%s" on public.%I for insert to authenticated with check ((select auth.uid()) = user_id)', t, t);
    EXECUTE format('create policy "user_update_%s" on public.%I for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id)', t, t);
    EXECUTE format('create policy "user_delete_%s" on public.%I for delete to authenticated using ((select auth.uid()) = user_id)', t, t);
    EXECUTE format('create index if not exists %I on public.%I(user_id)', t||'_user_id_idx', t);
  END LOOP;
END $$;

-- Storage policies for private walk photos. Create the bucket in Dashboard first: walk-photos
-- Files are stored under <user_id>/... and only the owning user may access them.
create policy "walk_photos_select_own" on storage.objects for select to authenticated using (bucket_id = 'walk-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "walk_photos_insert_own" on storage.objects for insert to authenticated with check (bucket_id = 'walk-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "walk_photos_update_own" on storage.objects for update to authenticated using (bucket_id = 'walk-photos' and (storage.foldername(name))[1] = (select auth.uid())::text) with check (bucket_id = 'walk-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "walk_photos_delete_own" on storage.objects for delete to authenticated using (bucket_id = 'walk-photos' and (storage.foldername(name))[1] = (select auth.uid())::text);
